import com.liferay.portal.service.AccountLocalService;
import com.liferay.portal.service.AccountLocalServiceWrapper;

public class ExtAccountLocalService extends AccountLocalServiceWrapper {

	public ExtAccountLocalService(AccountLocalService accountLocalService) {
		super(accountLocalService);
		// TODO Auto-generated constructor stub
	}
}
