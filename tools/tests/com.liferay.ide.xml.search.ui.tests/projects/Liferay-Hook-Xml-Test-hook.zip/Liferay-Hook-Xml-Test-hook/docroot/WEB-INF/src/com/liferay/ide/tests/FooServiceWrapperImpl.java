package com.liferay.ide.tests;

public class FooServiceWrapperImpl extends FooServiceWrapper {

}
