package com.liferay.ide.tests;

import com.liferay.portal.kernel.portlet.FriendlyURLMapper;
import com.liferay.portal.kernel.portlet.LiferayPortletURL;
import com.liferay.portal.kernel.portlet.Router;

import java.util.Map;


public class FriendlyURLMapperImpl implements FriendlyURLMapper
{

    @Override
    public String buildPath( LiferayPortletURL arg0 )
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public String getMapping()
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public String getPortletId()
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public Router getRouter()
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public boolean isCheckMappingWithPrefix()
    {
        // TODO Auto-generated method stub
        return false;
    }

    @Override
    public boolean isPortletInstanceable()
    {
        // TODO Auto-generated method stub
        return false;
    }

    @Override
    public void populateParams( String arg0, Map<String, String[]> arg1, Map<String, Object> arg2 )
    {
        // TODO Auto-generated method stub
        
    }

    @Override
    public void setMapping( String arg0 )
    {
        // TODO Auto-generated method stub
        
    }

    @Override
    public void setPortletId( String arg0 )
    {
        // TODO Auto-generated method stub
        
    }

    @Override
    public void setPortletInstanceable( boolean arg0 )
    {
        // TODO Auto-generated method stub
        
    }

    @Override
    public void setRouter( Router arg0 )
    {
        // TODO Auto-generated method stub
        
    }

}
