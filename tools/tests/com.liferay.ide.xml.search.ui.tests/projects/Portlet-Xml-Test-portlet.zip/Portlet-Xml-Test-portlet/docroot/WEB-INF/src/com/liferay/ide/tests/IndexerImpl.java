package com.liferay.ide.tests;

import com.liferay.portal.kernel.search.BooleanQuery;
import com.liferay.portal.kernel.search.Document;
import com.liferay.portal.kernel.search.Hits;
import com.liferay.portal.kernel.search.Indexer;
import com.liferay.portal.kernel.search.IndexerPostProcessor;
import com.liferay.portal.kernel.search.SearchContext;
import com.liferay.portal.kernel.search.SearchException;
import com.liferay.portal.kernel.search.Summary;
import com.liferay.portal.security.permission.PermissionChecker;

import java.util.List;
import java.util.Locale;

import javax.portlet.PortletRequest;
import javax.portlet.PortletResponse;
import javax.portlet.PortletURL;

public class IndexerImpl implements Indexer
{

    @Override
    public void addRelatedEntryFields( Document arg0, Object arg1 ) throws Exception
    {
        // TODO Auto-generated method stub
        
    }

    @Override
    public void delete( Object arg0 ) throws SearchException
    {
        // TODO Auto-generated method stub
        
    }

    @Override
    public void delete( long arg0, String arg1 ) throws SearchException
    {
        // TODO Auto-generated method stub
        
    }

    @Override
    public String[] getClassNames()
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public int getDatabaseCount() throws Exception
    {
        // TODO Auto-generated method stub
        return 0;
    }

    @Override
    public Document getDocument( Object arg0 ) throws SearchException
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public BooleanQuery getFacetQuery( String arg0, SearchContext arg1 ) throws Exception
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public BooleanQuery getFullQuery( SearchContext arg0 ) throws SearchException
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public IndexerPostProcessor[] getIndexerPostProcessors()
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public String getPortletId()
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public String getSearchEngineId()
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public String getSortField( String arg0 )
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public String getSortField( String arg0, int arg1 )
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public Summary getSummary( Document arg0, Locale arg1, String arg2, PortletURL arg3 ) throws SearchException
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public Summary getSummary( Document arg0, String arg1, PortletURL arg2, PortletRequest arg3, PortletResponse arg4 )
        throws SearchException
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public boolean hasPermission( PermissionChecker arg0, String arg1, long arg2, String arg3 ) throws Exception
    {
        // TODO Auto-generated method stub
        return false;
    }

    @Override
    public boolean isCommitImmediately()
    {
        // TODO Auto-generated method stub
        return false;
    }

    @Override
    public boolean isFilterSearch()
    {
        // TODO Auto-generated method stub
        return false;
    }

    @Override
    public boolean isPermissionAware()
    {
        // TODO Auto-generated method stub
        return false;
    }

    @Override
    public boolean isStagingAware()
    {
        // TODO Auto-generated method stub
        return false;
    }

    @Override
    public boolean isVisible( long arg0, int arg1 ) throws Exception
    {
        // TODO Auto-generated method stub
        return false;
    }

    @Override
    public boolean isVisibleRelatedEntry( long arg0, int arg1 ) throws Exception
    {
        // TODO Auto-generated method stub
        return false;
    }

    @Override
    public void postProcessContextQuery( BooleanQuery arg0, SearchContext arg1 ) throws Exception
    {
        // TODO Auto-generated method stub
        
    }

    @Override
    public void postProcessSearchQuery( BooleanQuery arg0, SearchContext arg1 ) throws Exception
    {
        // TODO Auto-generated method stub
        
    }

    @Override
    public void registerIndexerPostProcessor( IndexerPostProcessor arg0 )
    {
        // TODO Auto-generated method stub
        
    }

    @Override
    public void reindex( Object arg0 ) throws SearchException
    {
        // TODO Auto-generated method stub
        
    }

    @Override
    public void reindex( String[] arg0 ) throws SearchException
    {
        // TODO Auto-generated method stub
        
    }

    @Override
    public void reindex( String arg0, long arg1 ) throws SearchException
    {
        // TODO Auto-generated method stub
        
    }

    @Override
    public void reindexDDMStructures( List<Long> arg0 ) throws SearchException
    {
        // TODO Auto-generated method stub
        
    }

    @Override
    public Hits search( SearchContext arg0 ) throws SearchException
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public Hits search( SearchContext arg0, String... arg1 ) throws SearchException
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public void unregisterIndexerPostProcessor( IndexerPostProcessor arg0 )
    {
        // TODO Auto-generated method stub
        
    }

    @Override
    public void updateFullQuery( SearchContext arg0 )
    {
        // TODO Auto-generated method stub
        
    }

}
