package com.liferay.ide.tests;


import com.liferay.portal.kernel.portlet.LiferayPortletRequest;
import com.liferay.portal.kernel.portlet.LiferayPortletResponse;
import com.liferay.portal.theme.ThemeDisplay;
import com.liferay.portlet.dynamicdatamapping.model.DDMStructure;
import com.liferay.portlet.dynamicdatamapping.model.DDMTemplate;
import com.liferay.portlet.dynamicdatamapping.util.DDMDisplay;

import java.util.Locale;
import java.util.Set;
public class DDMDisplayImpl implements DDMDisplay
{

    @Override
    public String getAddStructureActionId()
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public String getAddTemplateActionId()
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public String getAvailableFields()
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public String getEditStructureDefaultValuesURL(
        LiferayPortletRequest arg0, LiferayPortletResponse arg1, DDMStructure arg2, String arg3, String arg4 )
        throws Exception
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public String getEditTemplateBackURL(
        LiferayPortletRequest arg0, LiferayPortletResponse arg1, long arg2, long arg3, String arg4 ) throws Exception
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public String getEditTemplateTitle( long arg0, Locale arg1 )
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public String getEditTemplateTitle( DDMStructure arg0, DDMTemplate arg1, Locale arg2 )
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public String getPortletId()
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public String getResourceName()
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public String getResourceName( long arg0 )
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public String getStorageType()
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public String getStructureName( Locale arg0 )
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public String getStructureType()
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public long[] getTemplateClassNameIds( long arg0 )
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public long[] getTemplateClassPKs( long arg0, long arg1, long arg2 ) throws Exception
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public long[] getTemplateGroupIds( ThemeDisplay arg0, boolean arg1 ) throws Exception
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public long getTemplateHandlerClassNameId( DDMTemplate arg0, long arg1 )
    {
        // TODO Auto-generated method stub
        return 0;
    }

    @Override
    public Set<String> getTemplateLanguageTypes()
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public String getTemplateMode()
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public String getTemplateType()
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public String getTemplateType( DDMTemplate arg0, Locale arg1 )
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public String getViewTemplatesBackURL( LiferayPortletRequest arg0, LiferayPortletResponse arg1, long arg2 )
        throws Exception
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public Set<String> getViewTemplatesExcludedColumnNames()
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public String getViewTemplatesTitle( DDMStructure arg0, Locale arg1 )
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public String getViewTemplatesTitle( DDMStructure arg0, boolean arg1, Locale arg2 )
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public String getViewTemplatesTitle( DDMStructure arg0, boolean arg1, boolean arg2, Locale arg3 )
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public boolean isShowAddStructureButton()
    {
        // TODO Auto-generated method stub
        return false;
    }

    @Override
    public boolean isShowStructureSelector()
    {
        // TODO Auto-generated method stub
        return false;
    }

}
