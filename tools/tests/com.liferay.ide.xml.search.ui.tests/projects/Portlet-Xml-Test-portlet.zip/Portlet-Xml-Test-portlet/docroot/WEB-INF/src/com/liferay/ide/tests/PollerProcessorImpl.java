package com.liferay.ide.tests;

import com.liferay.portal.kernel.poller.PollerException;
import com.liferay.portal.kernel.poller.PollerProcessor;
import com.liferay.portal.kernel.poller.PollerRequest;
import com.liferay.portal.kernel.poller.PollerResponse;


public class PollerProcessorImpl implements PollerProcessor
{

    @Override
    public PollerResponse receive( PollerRequest arg0 ) throws PollerException
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public void send( PollerRequest arg0 ) throws PollerException
    {
        // TODO Auto-generated method stub
        
    }

}
