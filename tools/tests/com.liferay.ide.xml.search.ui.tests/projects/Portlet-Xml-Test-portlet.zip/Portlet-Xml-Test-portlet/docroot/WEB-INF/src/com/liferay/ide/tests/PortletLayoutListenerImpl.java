package com.liferay.ide.tests;

import com.liferay.portal.kernel.portlet.PortletLayoutListener;
import com.liferay.portal.kernel.portlet.PortletLayoutListenerException;


public class PortletLayoutListenerImpl implements PortletLayoutListener
{

    @Override
    public void onAddToLayout( String arg0, long arg1 ) throws PortletLayoutListenerException
    {
        // TODO Auto-generated method stub
        
    }

    @Override
    public void onMoveInLayout( String arg0, long arg1 ) throws PortletLayoutListenerException
    {
        // TODO Auto-generated method stub
        
    }

    @Override
    public void onRemoveFromLayout( String arg0, long arg1 ) throws PortletLayoutListenerException
    {
        // TODO Auto-generated method stub
        
    }

    @Override
    public void onSetup( String arg0, long arg1 ) throws PortletLayoutListenerException
    {
        // TODO Auto-generated method stub
        
    }

}
