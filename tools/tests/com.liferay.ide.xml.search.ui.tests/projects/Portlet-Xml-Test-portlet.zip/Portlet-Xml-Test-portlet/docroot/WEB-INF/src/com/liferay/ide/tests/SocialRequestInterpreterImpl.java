package com.liferay.ide.tests;

import com.liferay.portal.theme.ThemeDisplay;
import com.liferay.portlet.social.model.SocialRequest;
import com.liferay.portlet.social.model.SocialRequestFeedEntry;
import com.liferay.portlet.social.model.SocialRequestInterpreter;

public class SocialRequestInterpreterImpl implements SocialRequestInterpreter
{

    @Override
    public String[] getClassNames()
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public SocialRequestFeedEntry interpret( SocialRequest arg0, ThemeDisplay arg1 )
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public boolean processConfirmation( SocialRequest arg0, ThemeDisplay arg1 )
    {
        // TODO Auto-generated method stub
        return false;
    }

    @Override
    public boolean processRejection( SocialRequest arg0, ThemeDisplay arg1 )
    {
        // TODO Auto-generated method stub
        return false;
    }

}
