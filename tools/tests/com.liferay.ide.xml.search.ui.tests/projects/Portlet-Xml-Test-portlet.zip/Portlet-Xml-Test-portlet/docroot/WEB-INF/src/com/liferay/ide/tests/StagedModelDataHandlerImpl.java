package com.liferay.ide.tests;


import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.lar.PortletDataContext;
import com.liferay.portal.kernel.lar.PortletDataException;
import com.liferay.portal.kernel.lar.StagedModelDataHandler;
import com.liferay.portal.kernel.xml.Element;
import com.liferay.portal.model.StagedModel;

import java.util.Map;
public class StagedModelDataHandlerImpl implements StagedModelDataHandler
{

    @Override
    public void deleteStagedModel( String arg0, long arg1, String arg2, String arg3 ) throws PortalException
    {
        // TODO Auto-generated method stub
        
    }

    @Override
    public void exportStagedModel( PortletDataContext arg0, StagedModel arg1 ) throws PortletDataException
    {
        // TODO Auto-generated method stub
        
    }

    @Override
    public StagedModel fetchMissingReference( String arg0, long arg1 )
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public StagedModel fetchStagedModelByUuidAndCompanyId( String arg0, long arg1 )
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public StagedModel fetchStagedModelByUuidAndGroupId( String arg0, long arg1 )
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public String[] getClassNames()
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public String getDisplayName( StagedModel arg0 )
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public int[] getExportableStatuses()
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public Map getReferenceAttributes( PortletDataContext arg0, StagedModel arg1 )
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public void importCompanyStagedModel( PortletDataContext arg0, Element arg1 ) throws PortletDataException
    {
        // TODO Auto-generated method stub
        
    }

    @Override
    public void importCompanyStagedModel( PortletDataContext arg0, String arg1, long arg2 ) throws PortletDataException
    {
        // TODO Auto-generated method stub
        
    }

    @Override
    public void importMissingReference( PortletDataContext arg0, Element arg1 ) throws PortletDataException
    {
        // TODO Auto-generated method stub
        
    }

    @Override
    public void importMissingReference( PortletDataContext arg0, String arg1, long arg2, long arg3 )
        throws PortletDataException
    {
        // TODO Auto-generated method stub
        
    }

    @Override
    public void importStagedModel( PortletDataContext arg0, StagedModel arg1 ) throws PortletDataException
    {
        // TODO Auto-generated method stub
        
    }

    @Override
    public void restoreStagedModel( PortletDataContext arg0, StagedModel arg1 ) throws PortletDataException
    {
        // TODO Auto-generated method stub
        
    }

    @Override
    public boolean validateReference( PortletDataContext arg0, Element arg1 )
    {
        // TODO Auto-generated method stub
        return false;
    }

}
