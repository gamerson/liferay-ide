package com.liferay.ide.tests;

import javax.portlet.PortletException;
import javax.portlet.PortletRequest;
import javax.portlet.PortletResponse;

import com.liferay.util.bridges.mvc.ActionCommand;

public class PortletActionImpl implements ActionCommand {

	@Override
	public boolean processCommand(PortletRequest arg0, PortletResponse arg1)
			throws PortletException {
		// TODO Auto-generated method stub
		return false;
	}

}
