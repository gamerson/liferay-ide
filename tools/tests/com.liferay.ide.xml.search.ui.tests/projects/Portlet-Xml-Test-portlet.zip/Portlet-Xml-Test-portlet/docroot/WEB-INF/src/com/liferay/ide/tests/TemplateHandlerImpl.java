package com.liferay.ide.tests;

import com.liferay.portal.kernel.template.TemplateHandler;
import com.liferay.portal.kernel.template.TemplateVariableGroup;
import com.liferay.portal.kernel.xml.Element;

import java.util.List;
import java.util.Locale;
import java.util.Map;

public class TemplateHandlerImpl implements TemplateHandler
{

    @Override
    public String getClassName()
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public List<Element> getDefaultTemplateElements() throws Exception
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public String getName( Locale arg0 )
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public String getResourceName()
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public String[] getRestrictedVariables( String arg0 )
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public Map<String, TemplateVariableGroup> getTemplateVariableGroups( long arg0, String arg1, Locale arg2 )
        throws Exception
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public String getTemplatesHelpContent( String arg0 )
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public String getTemplatesHelpPath( String arg0 )
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public String getTemplatesHelpPropertyKey()
    {
        // TODO Auto-generated method stub
        return null;
    }

}
