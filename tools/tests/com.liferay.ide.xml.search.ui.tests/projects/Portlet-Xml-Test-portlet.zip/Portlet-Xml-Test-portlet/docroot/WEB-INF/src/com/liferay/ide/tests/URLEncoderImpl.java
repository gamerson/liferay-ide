package com.liferay.ide.tests;

import com.liferay.portal.kernel.servlet.URLEncoder;

import javax.servlet.http.HttpServletResponse;

public class URLEncoderImpl implements URLEncoder
{

    @Override
    public String encodeURL( HttpServletResponse arg0, String arg1 )
    {
        // TODO Auto-generated method stub
        return null;
    }

}
