package com.liferay.ide.tests;


import com.liferay.portal.kernel.lar.DataLevel;
import com.liferay.portal.kernel.lar.ManifestSummary;
import com.liferay.portal.kernel.lar.PortletDataContext;
import com.liferay.portal.kernel.lar.PortletDataException;
import com.liferay.portal.kernel.lar.PortletDataHandler;
import com.liferay.portal.kernel.lar.PortletDataHandlerControl;
import com.liferay.portal.kernel.lar.StagedModelType;
import com.liferay.portal.model.Portlet;

import javax.portlet.PortletPreferences;
public class PortletDataHandlerImpl implements PortletDataHandler
{

    @Override
    public PortletPreferences addDefaultData( PortletDataContext arg0, String arg1, PortletPreferences arg2 )
        throws PortletDataException
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public PortletPreferences deleteData( PortletDataContext arg0, String arg1, PortletPreferences arg2 )
        throws PortletDataException
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public String exportData( PortletDataContext arg0, String arg1, PortletPreferences arg2 )
        throws PortletDataException
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public DataLevel getDataLevel()
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public String[] getDataPortletPreferences()
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public StagedModelType[] getDeletionSystemEventStagedModelTypes()
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public PortletDataHandlerControl[] getExportConfigurationControls( long arg0, long arg1, Portlet arg2, boolean arg3 )
        throws Exception
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public PortletDataHandlerControl[] getExportConfigurationControls(
        long arg0, long arg1, Portlet arg2, long arg3, boolean arg4 ) throws Exception
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public PortletDataHandlerControl[] getExportControls() throws PortletDataException
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public PortletDataHandlerControl[] getExportMetadataControls() throws PortletDataException
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public long getExportModelCount( ManifestSummary arg0 )
    {
        // TODO Auto-generated method stub
        return 0;
    }

    @Override
    public PortletDataHandlerControl[] getImportConfigurationControls( String[] arg0 )
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public PortletDataHandlerControl[] getImportConfigurationControls( Portlet arg0, ManifestSummary arg1 )
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public PortletDataHandlerControl[] getImportControls() throws PortletDataException
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public PortletDataHandlerControl[] getImportMetadataControls() throws PortletDataException
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public String getPortletId()
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public String getServiceName()
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public PortletPreferences importData( PortletDataContext arg0, String arg1, PortletPreferences arg2, String arg3 )
        throws PortletDataException
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public boolean isDataAlwaysStaged()
    {
        // TODO Auto-generated method stub
        return false;
    }

    @Override
    public boolean isDataLocalized()
    {
        // TODO Auto-generated method stub
        return false;
    }

    @Override
    public boolean isDataPortalLevel()
    {
        // TODO Auto-generated method stub
        return false;
    }

    @Override
    public boolean isDataPortletInstanceLevel()
    {
        // TODO Auto-generated method stub
        return false;
    }

    @Override
    public boolean isDataSiteLevel()
    {
        // TODO Auto-generated method stub
        return false;
    }

    @Override
    public boolean isDisplayPortlet()
    {
        // TODO Auto-generated method stub
        return false;
    }

    @Override
    public boolean isPublishToLiveByDefault()
    {
        // TODO Auto-generated method stub
        return false;
    }

    @Override
    public boolean isRollbackOnException()
    {
        // TODO Auto-generated method stub
        return false;
    }

    @Override
    public boolean isSupportsDataStrategyCopyAsNew()
    {
        // TODO Auto-generated method stub
        return false;
    }

    @Override
    public void prepareManifestSummary( PortletDataContext arg0 ) throws PortletDataException
    {
        // TODO Auto-generated method stub
        
    }

    @Override
    public void prepareManifestSummary( PortletDataContext arg0, PortletPreferences arg1 ) throws PortletDataException
    {
        // TODO Auto-generated method stub
        
    }

    @Override
    public PortletPreferences processExportPortletPreferences(
        PortletDataContext arg0, String arg1, PortletPreferences arg2 ) throws PortletDataException
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public PortletPreferences processImportPortletPreferences(
        PortletDataContext arg0, String arg1, PortletPreferences arg2 ) throws PortletDataException
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public void setPortletId( String arg0 )
    {
        // TODO Auto-generated method stub
        
    }

}
