package com.liferay.ide.tests;

import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.security.permission.PermissionPropagator;

import javax.portlet.ActionRequest;

public class PermissionPropagatorImpl implements PermissionPropagator
{

    @Override
    public void propagateRolePermissions( ActionRequest arg0, String arg1, String arg2, long[] arg3 )
        throws PortalException
    {
        // TODO Auto-generated method stub
        
    }

}
