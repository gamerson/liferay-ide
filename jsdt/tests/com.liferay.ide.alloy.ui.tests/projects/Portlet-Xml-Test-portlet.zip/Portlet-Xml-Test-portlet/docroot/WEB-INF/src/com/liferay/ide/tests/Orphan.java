package com.liferay.ide.tests;

public class Orphan {

}
